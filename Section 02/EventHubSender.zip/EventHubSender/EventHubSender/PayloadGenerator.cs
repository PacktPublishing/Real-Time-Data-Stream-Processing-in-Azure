﻿using System;
using System.Text;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Dynamic;

namespace EventHubSender
{
    public class PayloadGenerator
    {
        private static readonly Random Getrandom = new Random();
        List<string> _devicename = new List<string>() { "pump1", "pump2", "pump3", "pump4" };
        List<string> _ledColor = new List<string>() { "red", "yellow", "orange", "green" };

        public PayloadGenerator()
        {
        }

        public static int GetRandomNumber()
        {
            lock (Getrandom) //synchronize
            {
                return Getrandom.Next(1, 4);
            }
        }

        public string Payload()
        {
            dynamic data = new ExpandoObject();
            data.device = _devicename[GetRandomNumber()];
            data.ledColor = _ledColor[GetRandomNumber()];

            return JsonConvert.SerializeObject(data);

        }
    }
}
