﻿using System;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Threading.Tasks;

namespace EventHubSender
{
    class MainClass
    {
        private static EventHubClient eventHubClient;
        private const string EventConnectionString = "Endpoint=sb://mywonderfuleventhub.servicebus.windows.net/;SharedAccessKeyName=hubuser;SharedAccessKey=SUjz28wK4XJaA2k1Hbi4nIzIfk/81tCJdro5/fFza7c=";
        private const string EventHubName = "devicehub";

        public static void Main(string[] args)
        {
            MainAsync(args).GetAwaiter().GetResult();
            
        }

        private static async Task MainAsync(string[] args)
        {
            var connectionStringBuilder = new EventHubsConnectionStringBuilder(EventConnectionString)
            {
                EntityPath = EventHubName
            };
            eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());

            await SendMessagesToEventHub(100);

            Console.WriteLine("Press Enter To Exit");
            Console.ReadLine();


            await eventHubClient.CloseAsync();
        }

        private static async Task SendMessagesToEventHub(int numMessagesToSend)
        {
            

            for (int i = 0; i < numMessagesToSend; i++)
            {
                var message = new PayloadGenerator().Payload();

                Console.WriteLine($"Sending message: {message}");

                await eventHubClient.SendAsync(new EventData(Encoding.UTF8.GetBytes(message)));

                await Task.Delay(10);
            }

            Console.WriteLine($"{numMessagesToSend} messages sent");
        }
    }
}
